import msal
import dotenv
import os

dotenv.load_dotenv()

class MicrosoftGraphApi:
    """

    Microsoft Graph API client to handle authentication and token acquisition.

    :param tenant_id: The Azure AD tenant ID.
    :type tenant_id: str
    :param client_id: The Azure AD application client ID.
    :type client_id: str
    :param client_secret: The Azure AD application client secret.
    :type client_secret: str
    :param authority: The Azure AD authority URL.
    :type authority: str
    :param scope: The list of scopes for the API access.
    :type scope: list[str]
    :param app: The MSAL confidential client application instance.
    :type app: msal.ConfidentialClientApplication

    """
    tenant_id: str
    client_id: str
    client_secret: str
    authority: str
    scope: list[str]
    app: msal.ConfidentialClientApplication

    def __init__(self):
        """

        Initialize the MicrosoftGraphApi with credentials from environment variables.

        """
        self.tenant_id = os.getenv("TENANT_ID")
        self.client_id = os.getenv("CLIENT_ID")
        self.client_secret = os.getenv("CLIENT_SECRET")
        self.authority = os.getenv("AUTHORITY")
        self.scope = [os.getenv("SCOPE")]

        self.app = msal.ConfidentialClientApplication(
            self.client_id,
            authority=self.authority,
            client_credential=self.client_secret
        )

    def get_access_token(self) -> str | None:
        """

        Acquire an access token for client credentials flow.

        :return: The access token string.
        :rtype: str | None
        :raises Exception: If unable to acquire access token.

        """
        result = self.app.acquire_token_for_client(scopes=self.scope)

        if "access_token" not in result:
            raise Exception("Unable to acquire access token.")
        
        return result["access_token"]
    
if __name__ == "__main__":
    API = MicrosoftGraphApi()
    print(API.get_access_token())